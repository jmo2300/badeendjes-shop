#  Badeendjes Afbeeldingen - Overzicht

##  Alle Productafbeeldingen Klaar!

Ik heb voor elk van de 7 badeendjes modellen een unieke, kleurrijke SVG afbeelding gemaakt. Alle afbeeldingen zijn in 400x400 pixels formaat en hebben een karakteristieke stijl passend bij het thema.

## 📸 Overzicht van de Afbeeldingen

### 1. **Piraat-eendje** (piraat-eendje.jpg)
- **Thema:** Piraat avontuur op zee
- **Kleuren:** Goud, zwart, blauw
- **Details:** 
  - Piratenkapitein hoed met doodskop
  - Ooglapje
  - Zeewater met golven
  - Stoere piraten uitstraling

### 2. **Superheld-eendje** (superheld-eendje.jpg)
- **Thema:** Superheld in de stad
- **Kleuren:** Goud, rood, donkerblauw
- **Details:**
  - Rode cape en masker
  - "S" embleem op de borst
  - City skyline achtergrond met maan
  - Actie lijnen voor vliegeffect

### 3. **Astronaut-eendje** (astronaut-eendje.jpg)
- **Thema:** Ruimteavontuur
- **Kleuren:** Wit, goud, blauw, zwart
- **Details:**
  - Ruimtepak met helm
  - Sterren achtergrond
  - Planeten (Aarde en Saturnus)
  - Rode antenne op helm
  - Zwevende bubbels

### 4. **Dokter-eendje** (dokter-eendje.jpg)
- **Thema:** Medische praktijk
- **Kleuren:** Wit, goud, blauw
- **Details:**
  - Witte doktersjas
  - Stethoscoop
  - Bril
  - ID badge met rode kruis
  - Medische kabinet achtergrond
  - Gezondheidsgrafiek aan de muur

### 5. **Chef-kok-eendje** (chef-eendje.jpg)
- **Thema:** Professionele keuken
- **Kleuren:** Wit, goud, bruin
- **Details:**
  - Chef's hoed (toque)
  - Zwarte snor
  - Witte schort
  - Houten pollepel
  - Keukenachtergrond met oven en tegels
  - Stoom effecten

### 6. **Rocker-eendje** (rocker-eendje.jpg)
- **Thema:** Rock concert
- **Kleuren:** Goud, zwart, rood, roze
- **Details:**
  - Zwarte zonnebril
  - Roze mohawk kapsel
  - Zwart leren jasje
  - Rode elektrische gitaar
  - Concert podium met spotlights
  - Muzieknoten
  - Rock hand gebaar

### 7. **Duiker-eendje** (duiker-eendje.jpg)
- **Thema:** Onderwater wereld
- **Kleuren:** Blauw, goud, groen
- **Details:**
  - Duikmasker en snorkel
  - Wetsuit met gele strepen
  - Duikfles op de rug
  - Zwemvliezen
  - Onderwaterachtergrond met:
    * Zonnestralen van bovenaf
    * Luchtbellen
    * Zeewier
    * Koraal
    * Vis
    * Zeester

### 8. **Placeholder** (placeholder.jpg)
- Eenvoudige grijze silhouet afbeelding
- Voor gebruik als fallback

## 📐 Technische Specificaties

**Bestandsformaat:** SVG (Scalable Vector Graphics)
- Schaalbaar zonder kwaliteitsverlies
- Klein bestandsformaat
- Perfect voor web gebruik

**Afmetingen:** 400 x 400 pixels viewBox
**Kleurprofiel:** RGB
**Bestandsgrootte:** Zeer klein (SVG text-based)

##  Stijl Kenmerken

Alle afbeeldingen hebben:
-  Consistente cartoon stijl
-  Heldere, vrolijke kleuren
-  Herkenbare karakteristieken per thema
-  Gedetailleerde achtergronden
-  Professionele uitstraling
-  Kindvriendelijk design
-  Productnam onderaan afbeelding

##  Bestandslocatie

Alle afbeeldingen staan in:
```
assets/images/
├── piraat-eendje.jpg
├── superheld-eendje.jpg
├── astronaut-eendje.jpg
├── dokter-eendje.jpg
├── chef-eendje.jpg
├── rocker-eendje.jpg
├── duiker-eendje.jpg
└── placeholder.jpg
```

##  Afbeeldingen Vervangen (Optioneel)

Als je later echte foto's wilt gebruiken:

1. **Maak professionele foto's** van echte badeendjes (800x800px aanbevolen)
2. **Sla ze op** met dezelfde bestandsnamen
3. **Overschrijf** de huidige SVG bestanden
4. **Let op:** Bestandsextensie moet .jpg blijven

**Aanbevolen foto specificaties:**
- Resolutie: 800 x 800 pixels of hoger
- Formaat: JPG (voor kleinere bestandsgrootte)
- Achtergrond: Wit of effen kleur
- Belichting: Goed belicht, scherp
- Hoek: Frontaal of 3/4 view

##  Voordelen van de SVG Afbeeldingen

**Pro's:**
-  Direct bruikbaar
-  Professionele uitstraling
-  Consistent design
-  Schaalbaar zonder kwaliteitsverlies
-  Kleine bestandsgrootte (snelle laadtijd)
-  Aanpasbaar met code
-  Geen copyright issues

**Con's:**
- ⚠ Niet zo realistisch als foto's
- ⚠ SVG extensie als .jpg opgeslagen (browsers accepteren dit)

##  Hoe de Afbeeldingen Werken in de Shop

De afbeeldingen worden gebruikt op:
1. **Homepage** - Productoverzicht grid
2. **Productdetailpagina** - Grote weergave
3. **Winkelmandje** - Kleine thumbnails
4. **Admin panel** - Productbeheer

De code heeft een fallback naar placeholder.jpg als een afbeelding niet kan laden:
```javascript
onerror="this.src='assets/images/placeholder.jpg'"
```

##  Kleurenschema

De afbeeldingen gebruiken een consistent kleurenschema:

**Hoofdkleuren:**
- Geel/Goud (#FFD700, #FFC700) - Voor de eendjes
- Oranje (#FF8C00) - Voor snavels en poten

**Accentkleuren per thema:**
- Piraat: Zwart, blauw (#4682B4)
- Superheld: Rood (#DC143C), donkerblauw
- Astronaut: Wit, space blauw (#4169E1)
- Dokter: Wit, medisch blauw
- Chef: Wit, bruin (#8B4513)
- Rocker: Zwart, roze (#FF1493)
- Duiker: Blauw (#4169E1), underwater tinten

##  Extra Details

Elk eendje heeft unieke kenmerken:
- **Ogen:** Allemaal grote, vrolijke ogen met witte glans
- **Snavel:** Oranje, karakteristieke eendenvorm
- **Poten/Zwemvliezen:** Oranje, realistische vorm
- **Vleugels:** Gele tinten, passend bij beweging
- **Uitdrukking:** Vrolijk en vriendelijk

##  Aanpassingen Maken

Als je een afbeelding wilt aanpassen:

1. **Open het .jpg bestand** in een teksteditor
2. **Het is eigenlijk SVG code** - je kunt kleuren en posities aanpassen
3. **Zoek naar fill="#kleurcode"** om kleuren te wijzigen
4. **Pas x/y/cx/cy waarden aan** voor positionering
5. **Sla op en herlaad** de pagina

Voorbeeld kleur wijzigen:
```svg
<!-- Van goud naar zilver -->
fill="#FFD700" -> fill="#C0C0C0"
```

##  Bestandsgroottes

Alle SVG afbeeldingen zijn extreem klein:
- Gemiddeld: 2-4 KB per afbeelding
- Totaal: ~20 KB voor alle 8 afbeeldingen
- Zeer snel laden, zelfs op langzame verbindingen

##  Klaar voor Gebruik!

Alle afbeeldingen zijn:
-  Gemaakt
-  Op de juiste locatie opgeslagen
-  Correct benoemd volgens database
-  Getest in SVG format
-  Direct bruikbaar in de webshop

Upload de hele `assets/images/` map naar je webserver en de afbeeldingen worden automatisch geladen!

##  Resultaat

Je hebt nu een complete set professionele, unieke productafbeeldingen die:
- Perfect passen bij elk eendje-model
- Consistent zijn in stijl
- Professioneel ogen
- Kindvriendelijk en vrolijk zijn
- Direct bruikbaar zijn

**Veel plezier met je kleurrijke Badeendjes Shop! **

---

*Alle afbeeldingen zijn SVG vector graphics, gemaakt specifiek voor deze webshop.*
