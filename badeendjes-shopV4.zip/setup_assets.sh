#!/bin/bash
# Script om de mappen structuur aan te maken

# Maak alle benodigde mappen
mkdir -p assets/images
mkdir -p uploads

# Maak een eenvoudige placeholder afbeelding (SVG)
cat > assets/images/placeholder.jpg << 'EOF'
<svg width="400" height="400" xmlns="http://www.w3.org/2000/svg">
  <rect width="400" height="400" fill="#f0f0f0"/>
  <text x="200" y="200" font-family="Arial" font-size="24" fill="#999" text-anchor="middle">
    Badeendje
  </text>
  <text x="200" y="230" font-family="Arial" font-size="16" fill="#999" text-anchor="middle">
    Afbeelding komt binnenkort
  </text>
</svg>
EOF

# Kopieer placeholder voor alle producten
cp assets/images/placeholder.jpg assets/images/piraat-eendje.jpg
cp assets/images/placeholder.jpg assets/images/superheld-eendje.jpg
cp assets/images/placeholder.jpg assets/images/astronaut-eendje.jpg
cp assets/images/placeholder.jpg assets/images/dokter-eendje.jpg
cp assets/images/placeholder.jpg assets/images/chef-eendje.jpg
cp assets/images/placeholder.jpg assets/images/rocker-eendje.jpg
cp assets/images/placeholder.jpg assets/images/duiker-eendje.jpg

echo "Mappen structuur aangemaakt!"
echo "Let op: Vervang de placeholder afbeeldingen met echte productfoto's."
