#  Favicon Geactiveerd!

##  Favicon is Nu Actief

De favicon (het kleine icoontje in je browser tab) is nu geactiveerd voor de hele website!

##  Favicon Bestanden

Er zijn 3 favicon bestanden toegevoegd in de **root directory**:

```
badeendjes-shop/
├── favicon.svg          # Moderne browsers (SVG)
├── favicon.ico          # Oudere browsers (ICO)
└── apple-touch-icon.png # Apple devices (iPhone/iPad)
```

### Waar Staan Ze?

**Locatie: ROOT van je website** (niet in assets/images!)

```
/jouw-website/
├── favicon.svg          ← Hier!
├── favicon.ico          ← Hier!
├── apple-touch-icon.png ← Hier!
├── index.php
├── assets/
└── admin/
```

##  Design van de Favicon

De favicon is een **schattig geel badeendje**  met:
- Gele kleur (#FFD700)
- Zwarte ogen met witte glans
- Oranje snavel en pootjes
- Simpel en herkenbaar design

Perfect passend bij je badeendjes webshop!

##  Browser Ondersteuning

### Modern (SVG):
-  Chrome 80+
-  Firefox 41+
-  Safari 9+
-  Edge 79+

### Legacy (ICO):
-  Internet Explorer
-  Oudere browsers
-  Windows taskbar

### Apple Devices:
-  iPhone/iPad home screen
-  Safari tab
-  Touch icon

##  Hoe Het Werkt

In elke pagina is nu deze code toegevoegd in de `<head>`:

```html
<link rel="icon" type="image/svg+xml" href="favicon.svg">
<link rel="alternate icon" href="favicon.ico">
<link rel="apple-touch-icon" href="apple-touch-icon.png">
```

### Voor Pagina's in Submappen:

Admin en customer pagina's gebruiken relatieve paden:

```html
<link rel="icon" type="image/svg+xml" href="../favicon.svg">
<link rel="alternate icon" href="../favicon.ico">
<link rel="apple-touch-icon" href="../apple-touch-icon.png">
```

##  Geüpdateerde Pagina's

**Alle pagina's hebben nu een favicon:**

### Shop Pagina's:
-  index.php
-  product.php
-  cart.php
-  checkout.php

### Customer Pagina's:
-  login.php
-  register.php
-  account.php
-  orders.php
-  order_detail.php

### Admin Pagina's:
-  login.php
-  dashboard.php
-  products.php
-  orders.php
-  order_detail.php
-  discounts.php
-  statistics.php

##  Eigen Favicon Gebruiken?

Als je je eigen favicon wilt gebruiken:

### Optie 1: Vervang de Bestanden
1. Maak je eigen favicon (16x16, 32x32, of 180x180 pixels)
2. Sla op als `favicon.ico`, `favicon.svg`, of `apple-touch-icon.png`
3. Overschrijf de bestaande bestanden in de root

### Optie 2: Gebruik Online Tools
**Aanbevolen tools:**
- https://realfavicongenerator.net/ (genereert alle formaten)
- https://favicon.io/ (simpel en snel)
- Canva (voor design)

**Upload dan:**
1. favicon.ico (voor oudere browsers)
2. favicon.svg (voor moderne browsers)  
3. apple-touch-icon.png (180x180px voor Apple)

##  Tips

### Favicon Niet Zichtbaar?
1. **Hard refresh**: Ctrl+F5 (Windows) of Cmd+Shift+R (Mac)
2. **Cache legen**: Browser cache wissen
3. **Controleer pad**: Zorg dat favicon in root staat, niet in submap

### Favicon Testen
1. Open je website
2. Kijk naar de browser tab → Zie je het eendje? 
3. Test in verschillende browsers
4. Test op mobiel (bookmark op home screen)

### SEO Bonus
Een favicon helpt met:
-  Herkenbaarheid in browser tabs
-  Professionele uitstraling
-  Bookmarks herkennen
-  Google Search resultaten (soms getoond)

##  Favicon Kleurenschema

De huidige favicon gebruikt:
- **Geel**: #FFD700 (badeendje kleur)
- **Oranje**: #FF8C00 (snavel & pootjes)
- **Zwart**: #000000 (ogen)
- **Wit**: #FFFFFF (oog highlights)

Perfect passend bij je webshop theme!

##  Mobiele Weergave

### iOS (iPhone/iPad):
- Wanneer gebruiker je site toevoegt aan home screen
- `apple-touch-icon.png` wordt gebruikt (180x180px)
- Mooi afgerond met iOS styling

### Android:
- Gebruikt `favicon.svg` of `favicon.ico`
- Kan ook manifest.json gebruiken (optioneel)

##  Alles Werkt!

Na upload van de nieuwe versie:
1.  Favicon verschijnt in alle browser tabs
2.  Bookmark icon zichtbaar
3.  Apple touch icon voor mobiel
4.  Professionele uitstraling

**Je webshop heeft nu een complete branding met favicon!** 

---

*Favicon toegevoegd: November 2024*
*Alle pagina's geüpdatet* 
